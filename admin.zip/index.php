<?php 
    header("Location: ./site/trang-chinh/index.php");
?>
